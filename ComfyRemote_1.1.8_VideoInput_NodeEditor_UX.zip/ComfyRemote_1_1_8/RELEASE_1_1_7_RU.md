# Comfy Remote 1.1.7 build 9 — Video Input Fix

Исправление импорта видео в Input Media без обязательной замены PCRemoteServer 6.0.0.

- Load Video теперь распознаёт поля `file`, `video`, `video_file`, `input_video`, `source_video`, `path`, `filename`, `media` и другие скалярные input-поля.
- Галерея iPhone показывает и фото, и видео.
- Видео из Photos импортируется как исходный файл с корректным расширением.
- Проводник ПК теперь показывает PNG/JPG/WebP/GIF и MP4/MOV/M4V/WebM/AVI/MKV.
- Для видео в Input Media используется video-placeholder/preview вместо попытки декодировать его как UIImage.
- Надписи и ошибки Input Media сделаны нейтральными для фото и видео.
- PCRemoteServer остаётся версии 6.0.0; этот фикс относится к IPA.

Примечание: текущий стабильный сервер 6.0.0 ограничивает единичный Comfy Input upload 100 МБ. Для очень больших видео понадобится отдельный потоковый upload API в будущем серверном обновлении.
