# 1.1.7 build 9

- Исправлен импорт видео в Input Media из галереи iPhone и проводника ПК.
- Добавлена поддержка LoadVideo input с именем `file`.
- PCRemoteServer 6.0.0 не изменён.

## 1.1.6 build 8

- Исправлено применение Positive/Negative Prompt с главного экрана к реальному workflow.
- Динамический Input Media для Load Image / i2v / upscale: Галерея iPhone + Файлы ПК.
- Галерея: свайп фото/видео влево-вправо и «Изменить» с восстановлением исходных параметров.
- Stop Generation теперь прерывает текущую задачу и очищает оставшуюся очередь.
- `Ready` заменён на `Random Seed Generated`.
- Tailscale убран с ComfyUI-экрана и остаётся на login screen.
- Node editor: Load LoRA, duplicate node, viewport-aware add, более квадратные ноды, видимые inputs/outputs, haptics + red compatible connector glow, переработанный pan/zoom/fit.
- Windows Server поднят до стабильной линии API 6.0.0.
- GitHub Actions поддерживает сборку прямо из одного ZIP в корне репозитория.

## 1.1.4 build 6

- Кнопка **Tailscale на ПК** перенесена на экран входа, поэтому её видно до подключения к ComfyUI.
- Переключение Tailscale до входа защищено паролем PC Remote Server.
- Windows Server 5.2.4 добавляет безопасные pre-login endpoints для статуса и переключения Tailscale.
- Ошибка таймаута входа теперь показывает адрес/порт и подсказывает проверить `PCRemoteServer.exe`.

# Changelog

## 1.1.2 (build 4)

- Исправлен вылет iOS сразу после запуска: динамический `llama.xcframework` теперь встроен в `PCRemote.app/Frameworks`.
- Добавлены CodeSignOnCopy/RemoveHeadersOnCopy и явный runpath `@executable_path/Frameworks`.
- GitHub Actions проверяет наличие llama.framework внутри `.app` и IPA.

## 1.1.0 (build 2)

- Локальный iPhone-only Prompt Enhancer на Qwen3 0.6B + llama.cpp.
- Download/remove GGUF внутри приложения; модель не упаковывается в IPA, после загрузки проверяется целостность файла.
- Light / Detailed / Creative и ограничения «не менять персонажа/одежду».
- Локальные knowledge rules для WAN 2.2, Z-Image, Z-Image Turbo, SDXL.
- Новый последовательный Prompt Builder по профилю модели с сохранением выбранных слотов и заменой старого значения без дублирования.
- Расширенная библиотека ракурсов, света, камер, объективов, эмоций, взгляда, поз, Instagram-сцен и WAN camera motion.
- `− / +` для числовых Advanced inputs.
- Return/Go в Positive Prompt и кнопка `🎲 Generate` запускают новый seed + Generate.
- Улучшено определение model profile на Windows-сервере.

## 1.0.0

- Первый отдельный Comfy Remote только для ComfyUI.

## 1.1.3 build 5

- На главном экране Comfy Remote добавлена кнопка Tailscale ON/OFF для Windows-ПК.
- При выключении Tailscale через активное Tailscale-соединение приложение предупреждает, что связь с ПК будет потеряна.
- Windows Server 5.2.3 получил `/api/tailscale/status` и `/api/tailscale/set`.
- Отключение Tailscale запускается с небольшой задержкой после HTTP-ответа, чтобы телефон успел получить подтверждение.
- Каталог нод теперь принудительно обновляется из ComfyUI `/object_info` по кнопке обновления.
- Убран старый лимит 160 нод: сервер может отдавать до 1200 установленных нод.
- LoRA loader-ноды выводятся в отдельный верхний раздел; стандартный `LoraLoader` помечается как `Load LoRA`.
- Если `LoraLoader` не найден при первом открытии редактора, приложение автоматически делает принудительный refresh каталога.
